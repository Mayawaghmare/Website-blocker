# Website-Blocker
Website Blocker is useful when you want to concentrate on work.

FEATURES :

    Block the URL including the specified character string.
    Block only between the specified time.
    You can change the warning message.
    You can switch ON/OFF of each function.

About Incognito window:

    Open an Incognito window.
    Open an extension manager on Incognito window.
    Check an 'Allow in incognito' of 'Website Blocker'
